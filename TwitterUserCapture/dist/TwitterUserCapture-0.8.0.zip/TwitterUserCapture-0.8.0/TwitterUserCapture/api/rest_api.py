# -*- coding: UTF-8 -*-
# python2.7
from TwitterAPI import TwitterAPI
from TwitterAPI.TwitterError import TwitterConnectionError
from TwitterAPI.TwitterError import TwitterRequestError
import time
from multiprocessing.dummy import Pool
from ..data_storage import DataStorage
from ..constants import *
from ..tools import *
import logging


# 调用REST_API发送一次请求的封装
class API(object):
    def __init__(self, proxy=None,
                 data_storage=None,
                 token=None):
        """
        初始化：设置代理、token
        :param proxy: 设置代理，格式：'ip:port'
        :param data_storage: 设置数据库，见DataStorage类
        :param token: 设置token用于登录API，格式：
            {'consumer_key': '', 'consumer_secret': '', 'access_token': '', 'access_token_secret': ''}
        :return: 无
        """
        self.__proxy = proxy
        # 创建/连接数据库
        self.__data_storage = data_storage or DataStorage()
        self.__data_storage.update_collections([RECORD_COLLECTION])
        self.__token = token or {}
        self.__api = None
        self.set_api()

    def set_proxy(self, proxy='127.0.0.1:8118'):
        """
        设置代理
        :param proxy: 见初始化
        :return: 无
        """
        self.__proxy = proxy

    def set_token(self, token):
        """
        设置token
        :param token: 见初始化
        :return: 无
        """
        self.__token = token

    def set_api(self):
        """
        设置TwitterAPI（初始化以及重设了代理或token后调用）
        :return: 无
        """
        self.__api = TwitterAPI(consumer_key=self.__token.get('consumer_key'),
                                consumer_secret=self.__token.get('consumer_secret'),
                                access_token_key=self.__token.get('access_token'),
                                access_token_secret=self.__token.get('access_token_secret'),
                                proxy_url=self.__proxy)

    def get_users_lookup(self, user_list=None, with_screen_name=False, cl_name='user'):
        """
        补全用户信息
        :param user_list: 待采集详细信息的用户列表
        :param with_screen_name: 列表中是否包含screen_name
        :param cl_name: 存储结果的collection名
        :return: 无
        """
        logging.debug('start')
        account_id_list = []
        screen_name_list = []
        if not with_screen_name:
            account_id_list = user_list
        else:
            for data in user_list:
                if is_account_id(data):
                    account_id_list.append(data)
                elif is_screen_name(data):
                    screen_name_list.append(data.lower())
        user_num = len(account_id_list) + len(screen_name_list)
        commands = {}
        if account_id_list:
            commands.update({'user_id': account_id_list})
        if screen_name_list:
            commands.update({'screen_name': screen_name_list})
        if commands:
            commands.update({'include_entities': False})
        else:
            logging.warning('there is not valid user account_id or screen_name.')
            return
        # if list_type not in ['user_id', 'screen_name']:
        #     logging.error('unsupported list type: %s' % list_type)
        #     raise ValueError
        # # find_type为数据库中的字段名，list_type为API请求中的key值，其中的'use_id'对应数据库中的'account_id'
        # if list_type == 'screen_name':
        #     user_list = [user.lower() for user in user_list]
        #     find_type = 'screen_name'
        # else:
        #     find_type = 'account_id'
        try:
            # results = self.__api.request('users/lookup', {list_type: user_list, 'include_entities': False})
            results = self.__api.request('users/lookup', commands)
            if results.status_code >= 400:
                raise TwitterRequestError(results.status_code)
        except TwitterRequestError as err:
            logging.exception(err.status_code)
            if err.status_code == 404:  # 结果未找到
                # [self.__data_storage.update(cl_name, {find_type: user}, {'$set': {'alive': False}})
                #  for user in user_list]
                [self.__data_storage.update(cl_name, {'account_id': user}, {'$set': {'alive': False}})
                 for user in account_id_list]
                [self.__data_storage.update(cl_name, {'screen_name': user}, {'$set': {'alive': False}})
                 for user in screen_name_list]
                logging.info('users: %d, success: 0' % user_num)
                return
            else:
                raise TwitterRequestError(err.status_code)
        except TwitterConnectionError as err:
            logging.exception(err.message)
            raise
        else:
            try:
                for data in results:
                    result = self._load_user_info(data)
                    self.__data_storage.update(cl_name, {'account_id': result['account_id']}, {'$set': result},
                                               upsert=True)
                    if result['account_id'] in account_id_list:
                        account_id_list.remove(result['account_id'])
                    elif result['screen_name'].lower() in screen_name_list:
                        screen_name_list.remove(result['screen_name'].lower())
                        # user = result[find_type]
                        # user = user.lower() if isinstance(user, str) else user
                        # user_list.remove(user)
                # [self.__data_storage.update(cl_name, {find_type: user}, {'$set': {'alive': False}})
                #  for user in user_list]
                [self.__data_storage.update(cl_name, {'account_id': user}, {'$set': {'alive': False}})
                 for user in account_id_list]
                [self.__data_storage.update(cl_name, {'screen_name': user}, {'$set': {'alive': False}})
                 for user in screen_name_list]
                logging.info(
                    'users: %d, success: %d' % (user_num, user_num - len(account_id_list) - len(screen_name_list)))
            except Exception as err:
                logging.error(err.message)
                pass

    def get_users_ids(self, user, user_type='friends', cursor=-1, rest_users_num=INFINITE, update_cl_name=None,
                      upsert_cl_name=None):
        """
        获取用户的关注者或被关注者的ID
        :param user: 待采集用户的ID或screen_name
        :param user_type: 采集类型
        :param cursor: 采集开始位置，从头开始时为-1，没有数据时为0
        :param rest_users_num: 剩余采集个数，默认全部采集
        :return: next_cursor, rest_users_num: 下一次采集的开始位置和剩余数量
        :param update_cl_name: 待更新列表的用户所在collection名
        :param upsert_cl_name: 待插入新用户的collection名
        :return cursor, rest_num, get_num: 下一次采集开始位置、剩余采集个数、本次采集个数
        """
        logging.debug('start get %d %s, rest: %d' % (user, user_type, rest_users_num))
        count = API_FOLLOW_LIMIT if rest_users_num == INFINITE or rest_users_num > API_FOLLOW_LIMIT \
            else rest_users_num
        commands = None
        search_type = None
        if is_account_id(user):
            commands = {'user_id': user, 'cursor': cursor, 'count': count}
            search_type = 'account_id'
        elif is_screen_name(user):
            commands = {'screen_name': user, 'cursor': cursor, 'count': count}
            search_type = 'screen_name'
        if not commands:
            logging.warning('%s is not valid user account_id or screen_name.' % str(user))
            return 0, 0, 0
        try:
            # results = self.__api.request(user_type + '/ids', {'user_id': user, 'cursor': cursor, 'count': count})
            results = self.__api.request(user_type + '/ids', commands)
            if results.status_code >= 400:
                raise TwitterRequestError(results.status_code)
        except TwitterRequestError as err:
            if err.status_code == 401:  # 用户被保护
                self.__data_storage.update(update_cl_name, {search_type: user}, {'$set': {'protected': True}})
                # self.__data_storage.remove_local('record', {search_type: user})
                logging.info('%s: %s, protected' % (search_type, str(user)))
                return 0, 0, 0
            elif err.status_code == 404:  # 用户不存在
                self.__data_storage.update(update_cl_name, {search_type: user}, {'$set': {'alive': False}})
                # self.__data_storage.remove_local('record', {search_type: user})
                logging.info('%s: %s, not found' % (search_type, str(user)))
                return 0, 0, 0
            else:
                logging.exception(err.status_code)
                raise TwitterRequestError(err.status_code)
        except TwitterConnectionError as err:
            logging.exception(err.message)
            raise
        else:
            try:
                json_data = results.json()
                users_ids = json_data.get('ids')
            except Exception as err:
                logging.error(err.message)
                return cursor, rest_users_num, 0
            if upsert_cl_name and len(users_ids):
                self.__data_storage. \
                    insert(upsert_cl_name, [{'account_id': user_id, 'read': False} for user_id in users_ids],
                           continue_on_error=True)
            self.__data_storage.update(update_cl_name, {search_type: user},
                                       {'$addToSet': {user_type + '_ids': {'$each': users_ids}}},
                                       upsert=(search_type == 'account_id'))
            logging.info('%s: %s, type: %s, get: %d' % (search_type, str(user), user_type, len(users_ids)))
            next_cursor = json_data.get('next_cursor')
            rest_users_num = 0 if 0 < rest_users_num <= count \
                else rest_users_num - count if rest_users_num > count else rest_users_num
            return next_cursor, rest_users_num, len(users_ids)

    def users_search(self, keyword, page=1, count=API_SEARCH_LIMIT, cl_name='user'):
        """
        根据关键词搜索用户
        :param keyword: 关键词
        :param page: 搜索开始页数（从1开始）
        :param count: 每次返回结果条数（最多20条）
        :return: page：下一次搜索开始页数（为-1表示搜索结束）
        :param cl_name: 存放结果的collection名
        """
        logging.debug('start search %s' % keyword)
        if count > API_SEARCH_LIMIT:
            logging.error('count of search is too large.')
            raise ValueError
        try:
            results = self.__api. \
                request('users/search', {'q': keyword, 'page': page, 'count': count, 'include_entities': False})
            if results.status_code >= 400:
                raise TwitterRequestError(results.status_code)
        except TwitterRequestError as err:
            logging.exception(err.status_code)
            raise TwitterRequestError(err.status_code)
        except TwitterConnectionError as err:
            logging.exception(err.message)
            raise
        else:
            results_count = len([self.__data_storage.update(
                cl_name, {'account_id': result['account_id']}, {'$set': result}, upsert=True)
                                 for result in (self._load_user_info(data) for data in results)])
            return -1 if results_count < count else page + 1

    @staticmethod
    def _load_user_info(data):
        """
        转换Twitter返回的数据为待存储数据
        :param data: Twitter数据
        :return: 转换后数据
        """
        result = {'account_id': data['id'],
                  'screen_name': data['screen_name'],
                  'name': data['name'],
                  'profile_image_url_https': '400x400'.join(data['profile_image_url_https'].rsplit('normal', 1)),
                  'profile_banner_url':
                      data.get('profile_banner_url') + '/1500x500' if data.get('profile_banner_url') else None,
                  'statuses_count': data['statuses_count'],
                  'favourites_count': data['favourites_count'],
                  'friends_count': data['friends_count'],
                  'followers_count': data['followers_count'],
                  'geo_enabled': data['geo_enabled'],
                  'location': data['location'].strip(),
                  'time_zone': data['time_zone'],
                  'description': data['description'].replace('\r\n', ' ').replace('\n', ' ').replace('\r', ' ').strip(),
                  'lang': data['lang'].lower(),
                  'listed_count': data['listed_count'],
                  'protected': data['protected'],
                  'verified': data['verified'],
                  'alive': True,
                  'created_at': int(time.mktime(time.strptime(data['created_at'], "%a %b %d %H:%M:%S +0000 %Y"))),
                  'account_update_time': int(time.time() + time.timezone)}
        return result


# 多线程调用API
class MultiProcessAPI(object):
    def __init__(self, proxy=None, data_storage=None, token_db=None, debug=False):
        """
        初始化
        :param proxy: 设置代理，格式：'127.0.0.1:8080'
        :param data_storage: 设置数据库，见DataStorage类
        :param token_db: 设置token数据表，格式：{'host': 'ip:port', 'db': 'database_name', 'cl': 'collection_name'}
        :return: 无
        """
        self.__proxy = proxy
        self.__data_storage = data_storage if isinstance(data_storage, DataStorage) else DataStorage()
        self.__data_storage.update_collections([token_db or TOKEN_COLLECTION, RECORD_COLLECTION])
        cursor = self.__data_storage.get('token').find({'consumer_key': {'$exists': True}},
                                                       {'consumer_key': 1, 'consumer_secret': 1,
                                                        'access_token': 1, 'access_token_secret': 1, '_id': 0})
        self.__token_list = [data for data in cursor]
        self.debug = debug

    def get_users_lookup(self, process_num=PROCESS_COUNT, user_num=20000, cl_name=None,
                         account_id_list=None, screen_name_list=None):
        """
        批量获取用户详细信息
        :param process_num: 线程数
        :param user_num: 一次采集用户总数
        :param cl_name: collection名
        :param account_id_list: 指定用户id列表（为空时采集数据库中未采集过的用户）
        :param screen_name_list: 指定用户screen_name列表
        :return: 是否还有用户需要采集
        """
        if not cl_name:
            logging.error('no collection name')
            return False
        logging.debug('start')
        if not account_id_list and not screen_name_list:
            cursor = self.__data_storage.get(cl_name).find({'alive': None}, {'_id': 0, 'account_id': 1}).limit(user_num)
            if cursor.count(True) == 0:
                return False
            account_id_list = [user_id['account_id'] for user_id in cursor]
            if not self.debug:
                pool = Pool(process_num)
                [pool.apply_async(self.__get_users_lookup,
                                  (index * len(self.__token_list) / process_num, cl_name, data, None,))
                 for index, data in enumerate(list_split(account_id_list, num=process_num))]
                pool.close()
                pool.join()
            else:
                [self.__get_users_lookup(index * len(self.__token_list) / process_num, cl_name, data, None,)
                 for index, data in enumerate(list_split(account_id_list, num=process_num))]
            return True
        else:
            self.__get_users_lookup(0, cl_name, account_id_list, screen_name_list)
            return False

    def __get_users_lookup(self, token_index, cl_name, account_id_list=None, screen_name_list=None):
        """
        单线程获取用户详细信息
        :param account_id_list: 待采集用户ID列表，一次最多100个
        :param token_index: token列表的下标，用于选择token
        :return: 无
        """
        logging.debug('start')
        token = self.__token_list[token_index]
        api = API(proxy=self.__proxy, data_storage=self.__data_storage, token=token)
        if screen_name_list:
            with_screen_name = True
            user_list = account_id_list + screen_name_list
        else:
            with_screen_name = False
            user_list = account_id_list
        for sub_list in list_split(user_list, length=API_LOOKUP_LIMIT):
            success = False
            while not success:
                try:
                    api.get_users_lookup(user_list=sub_list, with_screen_name=with_screen_name, cl_name=cl_name)
                except TwitterConnectionError:
                    time.sleep(10)
                except TwitterRequestError as err:
                    if err.status_code == 429:
                        token_index = (token_index + 1) % len(self.__token_list)
                        api.set_token(self.__token_list[token_index])
                        api.set_api()
                    else:
                        pass
                else:
                    success = True

    def get_users_follow(self, process_num=4, user_num=None, max_list_num=MAX_FOLLOW, user_type='friends',
                         update_cl_name=None, upsert_cl_name=None, account_id_list=None, screen_name_list=None):
        """
        批量获取用户的friends或followers
        :param process_num: 线程数
        :param user_num: 一次采集用户总数
        :param max_list_num: 最多采集follow数
        :param user_type: 采集类型，有'friends'和'followers'两种
        :param update_cl_name: 待更新列表的用户所在collection名
        :param upsert_cl_name: 待插入新用户的collection名
        :param account_id_list: 指定待更新列表的用户id列表
        :param screen_name_list: 指定待更新列表的用户screen_name列表
        :return: 是否还有用户待采集
        """
        if not update_cl_name:
            logging.error('no collection name')
            return False
        logging.debug('start')
        # 根据用户采集列表的最大长度估计一个token可支持采集几个用户的列表，若小于等于0则为一个用户分配一个token，大于1时取整
        user_num_per_token = float(API_FOLLOW_TIME_LIMIT) * API_FOLLOW_LIMIT / max_list_num
        if user_num_per_token <= 0:
            user_num_per_token = 1
        elif user_num_per_token > 1:
            user_num_per_token = int(user_num_per_token)
        if not account_id_list and not screen_name_list:
            if not user_num:
                user_num = int(len(self.__token_list) * user_num_per_token)
            cursor = self.__data_storage.get(update_cl_name). \
                find({'last_update_' + user_type: {'$exists': False}, 'protected': False, 'alive': True},
                     {'_id': 0, 'account_id': 1}).limit(user_num)
            if cursor.count(True) == 0:
                return False
        else:
            cursor = account_id_list + screen_name_list
        if not self.debug:
            pool = Pool(process_num)
            [pool.apply_async(self.__get_users_follow,
                              (user_type, data if isinstance(data, (int, str)) else data['account_id'],
                               int(index / user_num_per_token) % len(self.__token_list),
                               update_cl_name, upsert_cl_name, max_list_num,)) for index, data in enumerate(cursor)]
            pool.close()
            pool.join()
        else:
            [self.__get_users_follow(user_type, data if isinstance(data, (int, str)) else data['account_id'],
                                     int(index / user_num_per_token) % len(self.__token_list), update_cl_name,
                                     upsert_cl_name, max_list_num) for index, data in enumerate(cursor)]
        return not account_id_list and not screen_name_list

    def __get_users_follow(self, user_type, user, token_index, update_cl_name, upsert_cl_name, max_list_num):
        """
        单线程获取用户的friends或followers
        :param user_type: 采集类型，有'friends'和'followers'两种
        :param user: 待采集用户ID或screen_name
        :param token_index: token列表的下标，用于选择token
        :param max_list_num: 最多采集个数
        :return: 无
        """
        logging.debug('start')
        token = self.__token_list[token_index]
        api = API(proxy=self.__proxy, data_storage=self.__data_storage, token=token)
        search_type = 'account_id' if isinstance(user, int) else 'screen_name'
        record = self.__data_storage.get('record').find_one({'type': 'api_' + user_type, search_type: user})
        if record:
            next_cursor = record.get('next_cursor')
            rest_num = record.get('rest_num')
        else:
            next_cursor = -1
            rest_num = max_list_num
        total_get_num = 0
        while 1:
            success = False
            while not success:
                try:
                    next_cursor, rest_num, get_num = \
                        api.get_users_ids(user, user_type, next_cursor, rest_num, update_cl_name, upsert_cl_name)
                except TwitterConnectionError:
                    time.sleep(10)
                except TwitterRequestError as err:
                    if err.status_code == 429:
                        token_index = (token_index + 1) % len(self.__token_list)
                        api.set_token(self.__token_list[token_index])
                        api.set_api()
                else:
                    success = True
                    total_get_num += get_num
                    if next_cursor == 0 or rest_num == 0:
                        self.__data_storage.remove_local('record', {'type': 'api_' + user_type, search_type: user})
                        self.__data_storage.update(
                            update_cl_name, {search_type: user},
                            {'$set': {'last_update_' + user_type: int(time.time() + time.timezone)}})
                        logging.info('%s: %s, type: %s, total: %d' % (search_type, str(user), user_type, total_get_num))
                        return
                    else:
                        self.__data_storage.update_local('record', {'type': 'api_' + user_type, search_type: user},
                                                         {'$set': {'next_cursor': next_cursor, 'rest_num': rest_num}},
                                                         upsert=True)
