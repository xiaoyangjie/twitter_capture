INFINITE = -1
PROXY = '127.0.0.1:8118'
HOST = "mongodb://192.168.178.101:27017, 192.168.178.104:27017/?replicaSet=twitter"

COOKIES_COLLECTION = {'host': HOST, 'db': 'twitter_cookie', 'cl': 'cookies'}
RECORD_COLLECTION = {'host': HOST, 'db': 'crawler_statuses', 'cl': 'temp_record', 'name': 'record'}
ID_COLLECTION = {'host': HOST, 'db': 'increasing_id', 'cl': 'account_id_info', 'name': 'id'}
USER_COLLECTION = {'host': HOST, 'db': 'twitter_user_tweet', 'cl': 'user', 'name': 'user'}
TOKEN_COLLECTION = {'host': HOST, 'db': 'crawler_statues', 'cl': 'twitter_apis', 'name': 'token'}
LOCAL_ONLY_COLLECTIONS = ['cookies', 'record', 'id', 'token']

HTTP_HEADER = {'Connection': 'Keep-Alive',
               'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
               'Accept-Language': 'en-US,en;q=0.8,zh-Hans-CN;q=0.5,zh-Hans;q=0.3',
               'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 '
                             '(KHTML, like Gecko) Chrome/31.0.1650.63 Safari/537.36',
               }

API_FOLLOW_LIMIT = 2500
API_FOLLOW_TIME_LIMIT = 15
API_SEARCH_LIMIT = 20
API_LOOKUP_LIMIT = 100
API_LOOKUP_TIME_LIMIT = 180
MAX_FOLLOW = 5000
PROCESS_COUNT = 8
