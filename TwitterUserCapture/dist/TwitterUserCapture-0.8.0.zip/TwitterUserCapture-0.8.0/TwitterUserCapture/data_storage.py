# -*- coding: UTF-8 -*-
from pymongo import MongoClient
import pymongo.errors
import commands
from .constants import *


# 封装了连接数据库，朝数据库和单导发送消息的功能
class DataStorage(object):
    def __init__(self, mongo_list=None, host=None, port=None, user=None, pwd=None):
        """
        初始化：连接mongo数据库
        :param mongo_list: mongo数据库列表，
            格式：[{'host': 'ip:port', 'db': 'database_name', 'cl': 'collection_name'}, {...}, ...]
        :return: 无
        """
        mongo_list = mongo_list or [USER_COLLECTION]
        self.collections = {}
        self.update_collections(mongo_list)
        self.host = host or '192.168.178.106'
        self.port = port or '55555'
        self.user = user or 'test'
        self.pwd = pwd or '123456'

    def update_collections(self, mongo_list):
        """
        连接新的数据表
        :param mongo_list:
        :return:
        """
        [self.collections.update({mongo.get('name', mongo.get('cl')): MongoClient(mongo.get('host')).
                                 get_database(mongo.get('db')).get_collection(mongo.get('cl'))})
         for mongo in mongo_list]

    def run(self, local_only, cl_name, command_type, *args, **kwargs):
        """
        朝数据库和单导发送相应请求
        :param local_only: 是否只保存在外网
        :param cl_name: collection_name, 目标数据表名
        :param command_type: 命令类型，目前有'update', 'insert', 'remove'三种操作
        :param args: 命令，根据类型而有所不同，与mongo命令相同
        :param kwargs: 命令，根据类型而有所不同，与mongo命令相同，包括upsert和multi两种可选参数
        :return: 无
        """
        if cl_name not in self.collections.keys():
            raise ValueError('can not find collection "%s"' % cl_name)
        if not local_only:
            self.__send_message(cl_name, command_type, *args, **kwargs)
        if command_type == 'insert':
            assert len(args) == 1, 'value number error'
            try:
                self.collections.get(cl_name).insert(args[0], **kwargs)
            except pymongo.errors.DuplicateKeyError:
                pass
            except pymongo.errors.BulkWriteError:
                pass
        elif command_type == 'update':
            assert len(args) == 2, 'value number error'
            assert isinstance(args[0], dict) and isinstance(args[1], dict), 'value error'
            self.collections.get(cl_name).update(args[0], args[1], **kwargs)
        elif command_type == 'remove':
            assert len(args) == 1, 'value number error'
            assert isinstance(args[0], dict), 'value error'
            self.collections.get(cl_name).remove(args[0], **kwargs)
        else:
            raise ValueError('command "%s" is unsupported.' % command_type)

    def insert(self, cl_name, *args, **kwargs):
        self.run(False, cl_name, 'insert', *args, **kwargs)

    def update(self, cl_name, *args, **kwargs):
        self.run(False, cl_name, 'update', *args, **kwargs)

    def remove(self, cl_name, *args, **kwargs):
        self.run(False, cl_name, 'remove', *args, **kwargs)

    def insert_local(self, cl_name, *args, **kwargs):
        self.run(True, cl_name, 'insert', *args, **kwargs)

    def update_local(self, cl_name, *args, **kwargs):
        self.run(True, cl_name, 'update', *args, **kwargs)

    def remove_local(self, cl_name, *args, **kwargs):
        self.run(True, cl_name, 'remove', *args, **kwargs)

    def get(self, cl_name):
        return self.collections.get(cl_name)

    # 往单导发送数据
    def __send_message(self, collection_name, *args, **kwargs):
        message = '\"%s\"' % str({collection_name: list(args) + [kwargs]}). \
            replace('"', '\\\"').replace('`', '\`').replace('$', '\$')
        # print 'message: %s' % message
        status, _ = commands.getstatusoutput('/home/server-cj/software/ClientDemo -ip %s -port %s '
                                             '-user %s -pwd %s -buflen %d -msg %s -debug' %
                                             (self.host, str(self.port), self.user, self.pwd,
                                              len(message) + 20, message))
        print 'status: %s' % status
