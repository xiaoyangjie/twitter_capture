from pykafka import KafkaClient


class Producer:
    def __init__(self, brokers, topic):
        self.__client = KafkaClient(hosts=brokers)
        self.__topic = self.__client.topics[topic]
        self.__producer = self.__topic.get_producer()
        self.__producer.start()

    def __del__(self):
        self.__producer.stop()
        
    def __send_message(self, data):
        self.__producer.produce(data)

    def send_message(self, data):
        self.__send_message(data)

    def update(self, query, update_data, **args):
        data = {'key': query, 'value': update_data}
        args_list = []
        print args
        for key, value in args:
            args_list.append({key: value})
        data['args_list'] = args_list
        self.__send_message(str(data))
